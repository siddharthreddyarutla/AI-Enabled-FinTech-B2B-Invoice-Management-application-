package com.highradius;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class Display extends Crud {
	
	
	
	public ArrayList<winter_internship> getData()
	{
		ArrayList<winter_internship> ALLStudents =new ArrayList<winter_internship>();	
		
		try {
		 Connection conn = getConnection();
		 String sql_query="SELECT * from winter_internship";
		 PreparedStatement prestatement = conn.prepareStatement(sql_query);
	
		 
		 ResultSet rs = prestatement.executeQuery();
		
		 while(rs.next())
		 {
				winter_internship s = new winter_internship();
			 	
				//The get method returns the value of the variable name .
				//The set method takes a parameter ( newName ) and assigns it to the name variable. 
			
				
				s.setSl_no(rs.getInt("sl_no"));
				s.setbCode(rs.getString("business_code"));
				s.setCustNumber(rs.getString("cust_number"));
				s.setClear_date(rs.getString("clear_date"));
				s.setBussinessyear(rs.getString("buisness_year"));
				s.setDocid(rs.getString("doc_id"));
				s.setPostingdate(rs.getString("posting_date"));
				s.setDocumentcreatedate(rs.getString("document_create_date"));
             //	s.setDocumentcreatedate1(rs.getString("document_create_date1"));
				s.setDue_in_date(rs.getString("due_in_date"));
				s.setInvoice_currency(rs.getString("invoice_currency"));
				s.setDocument_type(rs.getString("document_type"));
				s.setPosting_id(rs.getString("posting_id"));
				s.setArea_business(rs.getString("area_business"));
				s.setTotal_open_amount(rs.getString("total_open_amount"));
				s.setBaseline_create_date(rs.getString("baseline_create_date"));
				s.setCust_payment_terms(rs.getString("cust_payment_terms"));
				s.setInvoice_id(rs.getString("invoice_id"));
				s.setIsOpen(rs.getString("isOpen"));
				s.setPredicted(rs.getString("aging_bucket"));
				s.setIs_deleted(rs.getString("is_deleted"));
//				s.setBussiness_name(rs.getString("business_name"));
//				s.setName_customer(rs.getString("name_customer"));
				
				ALLStudents.add(s);
				
				
		 }
		 
		 for(winter_internship stud: ALLStudents)
		 {
			 System.out.println(stud.toString());
		 }
		 
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
		
		return ALLStudents;
		
	
	}

}