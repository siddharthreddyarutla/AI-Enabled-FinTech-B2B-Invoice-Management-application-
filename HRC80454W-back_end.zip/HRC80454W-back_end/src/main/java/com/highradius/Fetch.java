package com.highradius;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson; 
//Google Gson is a simple Java-based library to serialize Java objects to JSON and vice versa
//Serialization is a mechanism of converting the state of an object into a byte stream.
/**
 * Servlet implementation class Fetch
 */
@WebServlet("/Fetch") 
// The @WebServlet annotation is used to define a Servlet component in a web application

public class Fetch extends HttpServlet  {
	private static final long serialVersionUID = 1L;
//	a universal version identifier for a Serializable class
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fetch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		 Display fetchdata=new Display();
		 
		  ArrayList<winter_internship> data = fetchdata.getData();
		  //System.out.println(data);
		  	
		  	Gson gson = new Gson();
			String responseData = gson.toJson(data);
            //response.setHeader("Access-Control-Allow-Origin","*");
			response.getWriter().print(responseData);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}