import React from "react";
import "./components/css/homepage.css";
import abc from "./images/abc.png";
import hrclogo from "./images/logo.png";
import Addbutton from "./components/Addbutton";
import { useState } from "react";
import Editbutton from "./components/Editbutton";
import Deletebutton from "./components/Deletebutton";
import AdvanceSearch from "./components/AdvanceSearch";
import Simplesearch from "./components/SimpleSearch";

const Home = ({ currentrowid, selectedRows, setTabledata }) => {
  const [openAddButton, setAddButton] = useState(false);
  const [openEditButton, setEditButton] = useState(false);
  const [openDeleteButton, setDeleteButton] = useState(false);
  const [opensearchButton, setsearchButton] = useState(false);

  function refreshPage() {
    window.location.reload(false);
  }

  return (
    <>
      <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>HRC_FINAL</title>
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="/components/css/homepage.css" />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
        />
        {/* <script defer src="/javascript/add.js" /> */}
      </head>

      <body>
        <header id="header">
          <img class="abclogo" src={abc} alt="abclogo" />
          <span>
            <img class="hrclogo" src={hrclogo} alt="HRC logo" />
          </span>
        </header>
        <div>
          <div id="content">
            <span class="btn-group">
              <button type="button" class="predictbutton">
                PREDICT
              </button>
              <button type="button" class="analyticsbutton">
                ANALYTICS VIEW
              </button>
              <button
                type="button"
                class="advancebutton"
                onClick={() => {
                  setsearchButton(true);
                }}
              >
                ADVANCE SEARCH
              </button>
              <button
                type="button"
                class="refresh-button"
                onClick={refreshPage}
              >
                <i class="fa fa-refresh"></i>
              </button>
              {/* fa fa-refresh fa-spin */}
              <Simplesearch setTabledata={setTabledata} />

              <div class="btn-group1">
                <button
                  type="button"
                  class="deletebutton"
                  onClick={() => {
                    setDeleteButton(true);
                  }}
                >
                  DELETE
                </button>
                <button
                  type="button"
                  class="editButton"
                  onClick={() => {
                    setEditButton(true);
                  }}
                >
                  EDIT
                </button>
                <button
                  type="button"
                  class="addButton"
                  onClick={() => {
                    setAddButton(true);
                  }}
                >
                  ADD
                </button>
                {openEditButton && (
                  <Editbutton
                    closeEditbutton={setEditButton}
                    currentrowid={currentrowid}
                  />
                )}{" "}
                {openDeleteButton && (
                  <Deletebutton
                    closeDeletebutton={setDeleteButton}
                    selectedRows={selectedRows}
                  />
                )}
                {openAddButton && <Addbutton closeAddbutton={setAddButton} />}
                {opensearchButton && (
                  <AdvanceSearch
                    closesearchbutton={setsearchButton}
                    setTabledata={setTabledata}
                  />
                )}
              </div>
            </span>
          </div>
        </div>
      </body>
      <div></div>
    </>
  );
};

export default Home;
