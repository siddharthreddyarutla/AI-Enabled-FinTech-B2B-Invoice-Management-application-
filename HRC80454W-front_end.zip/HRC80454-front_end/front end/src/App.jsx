import React, { useState } from "react";
import Home from "./Home";
// import SearchDataTable from "./components/SearchDataTable";

import DataTable from "./components/DataTable";

function App() {
  const [currentrowid, setcurrentrowid] = useState(null);
  const [selectedRows, setSelectedRows] = useState([]);
  const [tableData, setTableData] = useState([]);

  console.log(tableData);
  return (
    <>
      <div className="Home">
        <Home
          currentrowid={currentrowid}
          selectedRows={selectedRows}
          setTabledata={setTableData}
        />
        {/* <SearchDataTable /> */}
      </div>
      <DataTable
        setcurrentrowid={setcurrentrowid}
        setSelectedRows={setSelectedRows}
        setTableData={setTableData}
        tableData={tableData}
      />
      {/* <SearchDataTable /> */}
    </>
  );
}

export default App;
