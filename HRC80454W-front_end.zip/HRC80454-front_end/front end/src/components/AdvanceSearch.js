import React from "react";
import { useState } from "react";
import "./AdvanceSearch.css";
// import SearchDataTable from "./SearchDataTable";
// import search1 from "./SearchDataTable";
import { search1 } from "./data.js";

const AdvanceSearch = (props) => {
  console.log(props);
  const { closesearchbutton, setTabledata } = props;
  const [Searchbutton1, setSearchbutton1] = useState({
    doc_id: "",
    invoice_id: "",
    cust_num: "",
    buss_year: "",
  });
  const { doc_id, invoice_id, cust_num, buss_year } = Searchbutton1;

  const changeHandler = (e) => {
    setSearchbutton1({ ...Searchbutton1, [e.target.name]: e.target.value });
  };
  const [response, setResponse] = useState();

  const submitHandler = async (e) => {
    e.preventDefault();

    search1(Searchbutton1).then((data) => setTabledata(data));
  };

  return (
    <>
      <form>
        <div className="holder1">
          <div className="advsearchbackground">
            <span>
              <h1 className="addtitle">Advance Search</h1>
            </span>
            <div className="searchinputfields">
              <label class="adv_style1" for="doc_id">
                Document ID
              </label>
              <label class="adv_style2" for="invoice">
                Invoice ID
              </label>
              <div className="adv_setone">
                <input
                  id="doc_id"
                  type="text"
                  name="doc_id"
                  value={doc_id}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Document ID"
                />
                <input
                  id="invoice_id"
                  type="text"
                  name="invoice_id"
                  value={invoice_id}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Invoice ID"
                />
              </div>
              <label class="adv_style3" for="doc_id">
                Customer Number
              </label>
              <label class="adv_style4" for="invoice">
                Bussiness Year
              </label>
              <div className="adv_setone">
                <input
                  id="cust_num"
                  type="number"
                  name="cust_num"
                  value={cust_num}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Customer Number"
                />
                <input
                  id="buss_year"
                  type="text"
                  name="buss_year"
                  value={buss_year}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Bussiness Year"
                />
              </div>
            </div>
            <br />

            <div class="searchbuttons">
              <div>
                <input
                  type="submit"
                  value={"Search"}
                  class="searchbutton"
                  onClick={(e) => submitHandler(e)}
                ></input>

                <button
                  class="cancelbutton1"
                  onClick={() => closesearchbutton(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};

export default AdvanceSearch;
