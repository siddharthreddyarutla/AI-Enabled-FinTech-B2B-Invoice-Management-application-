import React, { useState } from "react";
import "./Addbutton.css";
import { add1 } from "./data.js";

const Addbutton = ({ closeAddbutton }) => {
  const [Addbutton1, setAddbutton1] = useState({
    buss_code: "",
    cust_num: "",
    clear_date: "",
    buss_year: "",
    doc_id: "",
    pos_date: "",
    d_date: "",
    due_date: "",
    invoice: "",
    doc_type: "",
    pos_id: "",
    total: "",
    bc_date: "",
    cpt: "",
    invoice_id: "",
  });

  const {
    buss_code,
    cust_num,
    clear_date,
    buss_year,
    doc_id,
    pos_date,
    d_date,
    due_date,
    invoice,
    doc_type,
    pos_id,
    total,
    bc_date,
    cpt,
    invoice_id,
  } = Addbutton1;
  const submitHandler = async (e) => {
    e.preventDefault();

    let response = add1(Addbutton1);

    if (response) {
      setAddbutton1({
        buss_code: "",
        cust_num: "",
        clear_date: "",
        buss_year: "",
        doc_id: "",
        pos_date: "",
        d_date: "",
        due_date: "",
        invoice: "",
        doc_type: "",
        pos_id: "",
        total: "",
        bc_date: "",
        cpt: "",
        invoice_id: "",
      });
    }
  };

  const changeHandler = (e) => {
    setAddbutton1({ ...Addbutton1, [e.target.name]: e.target.value });
  };

  // useEffect(async () => {
  //   setdata(await data());
  // }, []);

  return (
    <>
      <form>
        <div className="holder">
          <div className="addpopupbackground">
            <span>
              <h1 className="addtitle">Add</h1>
            </span>
            <div className="inputfields">
              <label class="style1" for="buss_code">
                Bussiness Code
              </label>
              <label class="style2" for="cust_num">
                Customer Number
              </label>
              <label class="style3" for="clear_date">
                Clear Date
              </label>
              <label class="style4" for="buss_year">
                Bussiness Year
              </label>
              <div className="addsetone">
                <input
                  id="buss_code"
                  type="text"
                  name="buss_code"
                  value={buss_code}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Bussiness Code"
                />
                <input
                  id="cust_num"
                  type="Number"
                  name="cust_num"
                  value={cust_num}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Customer Number"
                />
                <input
                  id="clear_date"
                  type="date"
                  name="clear_date"
                  value={clear_date}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Clear Date"
                />
                <input
                  id="buss_year"
                  name="buss_year"
                  type="Number"
                  value={buss_year}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Bussiness Year"
                />
              </div>
              <br />

              <label class="style5" for="doc_id">
                Document ID
              </label>
              <label class="style6" for="pos_date">
                Posting Date
              </label>
              <label class="style7" for="d_date">
                Document Create Date
              </label>
              <label class="style8" for="due_date">
                Due Date
              </label>
              <div>
                <input
                  id="doc_id"
                  type="Number"
                  value={doc_id}
                  name="doc_id"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Document ID"
                />
                <input
                  id="pos_date"
                  type="date"
                  name="pos_date"
                  value={pos_date}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Posting Date"
                />
                <input
                  id="d_date"
                  type="date"
                  value={d_date}
                  name="d_date"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Document Create Date"
                />
                <input
                  id="due_date"
                  type="date"
                  value={due_date}
                  name="due_date"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Due Date"
                />
              </div>
              <br />
              <label class="style9" for="invoice">
                Invoice Currency
              </label>
              <label class="style10" for="doc_type">
                Document Type
              </label>
              <label class="style11" for="pos_id">
                Posting ID
              </label>
              <label class="style12" for="total">
                Total Open Amount
              </label>

              <div>
                <input
                  id="invoice"
                  type="text"
                  value={invoice}
                  name="invoice"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Invoice Currency"
                />
                <input
                  id="doc_type"
                  type="text"
                  value={doc_type}
                  name="doc_type"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Document Type"
                />
                <input
                  id="pos_id"
                  type="Number"
                  name="pos_id"
                  value={pos_id}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Posting ID"
                />
                <input
                  id="total"
                  type="Number"
                  name="total"
                  value={total}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Total Open Amount"
                />
              </div>

              <br />
              <label class="style13" for="bc_date">
                Bussiness Create Date
              </label>
              <label class="style14" for="cpt">
                Customer Payment Terms
              </label>
              <label class="style15" for="invoice_id">
                Invoice ID
              </label>

              <div>
                <input
                  id="bc_date"
                  type="date"
                  value={bc_date}
                  name="bc_date"
                  onChange={(e) => changeHandler(e)}
                  placeholder="Bussiness Create Date"
                />
                <input
                  id="cpt"
                  type="text"
                  name="cpt"
                  value={cpt}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Customer Payment Terms"
                />
                <input
                  id="invoice_id"
                  type="Number"
                  name="invoice_id"
                  value={invoice_id}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Invoice ID"
                />
                <span>
                  <input
                    type="submit"
                    value={"Add"}
                    class="Add"
                    onClick={(e) => submitHandler(e)}
                  ></input>
                  <input
                    type="cancel"
                    class="Cancel"
                    value={"Cancel"}
                    onClick={() => closeAddbutton(false)}
                  />
                </span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};

export default Addbutton;
