import React from "react";
import { edit1 } from "./data.js";
import { useState } from "react";
import "./Editbutton.css";

function Editbutton(props) {
  console.log(props);
  const { closeEditbutton, currentrowid } = props;
  const [editbutton1, seteditbutton1] = useState({
    sl_no: currentrowid,
    invoice: "",
    cpt: "",
  });
  const { sl_no, invoice, cpt } = editbutton1;

  const changeHandler = (e) => {
    seteditbutton1({ ...editbutton1, [e.target.name]: e.target.value });
  };
  const submitHandler = async (e) => {
    e.preventDefault();
    let response = edit1(editbutton1);

    if (response) {
      seteditbutton1({
        invoice: "",

        cpt: "",
      });
    }
  };

  return (
    <>
      <form>
        <div className="holder">
          <div className="editpopupbackground">
            <span>
              <h1 className="addtitle">Edit</h1>
            </span>
            <div className="editinputfields">
              <label class="style16" for="buss_code">
                Invoice Currency
              </label>
              <label class="style17" for="cust_num">
                Customer Payment Terms
              </label>
              <div className="editsetone">
                <input
                  id="invoice"
                  type="text"
                  name="invoice"
                  value={invoice}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Invoice Currency"
                />
                <input
                  id="cpt"
                  type="text"
                  name="cpt"
                  value={cpt}
                  onChange={(e) => changeHandler(e)}
                  placeholder="Customer Payment Terms"
                />
              </div>
            </div>
            <br />

            <div class="editbuttons">
              <div>
                <input
                  type="submit"
                  value={"Edit"}
                  class="editbutton"
                  onClick={(e) => submitHandler(e)}
                ></input>
                <button
                  class="cancelbutton"
                  onClick={() => closeEditbutton(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
}

export default Editbutton;
