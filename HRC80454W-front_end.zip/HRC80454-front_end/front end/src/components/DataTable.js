import React, { useState, useEffect } from "react";
import { DataGrid } from "@material-ui/data-grid";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import axios from "axios";
import Editbutton from "./Editbutton";

import "./DataTable.css";

// import { Box, ThemeProvider, createTheme } from "@mui/system";
// /** @jsxImportSource theme-ui */
import "@mui/material/styles";

// import axios from "axios";

const columns = [
  { field: "sl_no", headerName: "Sl No", width: 150 },
  { field: "bCode", headerName: "Bussiness Code", width: 200 },
  { field: "custNumber", headerName: "Customer Number", width: 200 },
  { field: "clear_date", headerName: "Clear Date", width: 200 },
  { field: "bussinessyear", headerName: "Bussiness year", width: 200 },
  { field: "docid", headerName: "Doc ID", width: 150 },
  { field: "postingdate", headerName: "Posting Date", width: 200 },
  {
    field: "documentcreatedate",
    headerName: "Document create date",
    width: 200,
  },
  { field: "due_in_date", headerName: "Due in Date", width: 200 },
  { field: "invoice_currency", headerName: "Invoice Currency", width: 200 },
  { field: "document_type", headerName: "Document Type", width: 200 },
  { field: "posting_id", headerName: "Posting ID", width: 200 },

  { field: "total_open_amount", headerName: "Total open amount", width: 200 },
  {
    field: "baseline_create_date",
    headerName: "Baseline create date",
    width: 200,
  },
  { field: "cust_payment_terms", headerName: "cust payment terms", width: 200 },
  { field: "invoice_id", headerName: "Invoice ID", width: 200 },
];

const DataTable = ({
  setcurrentrowid,
  setSelectedRows,
  tableData,
  setTableData,
}) => {
  const [tablestate, settablestate] = useState([]);

  const [pageSize, setPageSize] = React.useState(10);

  useEffect(() => {
    fetch("http://localhost:8080/HRC80454W-back_end/Fetch")
      .then((data) => data.json())
      .then((data) => settablestate(data));
  }, []);

  useEffect(() => {
    settablestate(tableData);
  }, [tableData]);

  console.log(tableData, tablestate);

  return (
    <div
      style={{
        // zIndex: "0 !important",
        height: 450,
        width: "100%",
        backgroundColor: "#69808d79",
      }}
    >
      <DataGrid
        sx={{
          "& MuiTablePagination-root": {
            textOverflow: "clip",
            whiteSpace: "break-spaces",
            color: "white",
            lineHeight: 3,
          },
        }}
        rows={tablestate}
        classes={{ root: "datagrid", body2: "datagrid" }}
        getRowId={(row) => row.sl_no}
        columns={columns}
        pageSize={pageSize}
        onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        rowsPerPageOptions={[6, 10, 20, 30, 40, 50]}
        pagination={true}
        {...tableData}
        checkboxSelection
        onSelectionModelChange={(ids) => {
          setcurrentrowid(ids[0]);
          setSelectedRows(ids);
          console.log(ids);
          console.log(ids[0]);
        }}
      />
    </div>
  );
};

export default DataTable;
